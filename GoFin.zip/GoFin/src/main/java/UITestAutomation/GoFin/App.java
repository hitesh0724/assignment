package UITestAutomation.GoFin;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.HashMap;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


public class App extends TestBase {

	public static void Checkout_with(HashMap<String, String> data, WebDriver driver ,WebDriverWait myWait,String Case) throws AWTException, InterruptedException {
		
		//Click on Buy Now button
		myWait.until(ExpectedConditions.visibilityOfElementLocated(buynow_button));
		driver.findElement(buynow_button).click();
		
		//Click on Checkout button
		myWait.until(ExpectedConditions.visibilityOfElementLocated(checkout_button));
		driver.findElement(checkout_button).click();

		//Switch to iFrame MindTrans
		driver.switchTo().frame("snap-midtrans");
		myWait.until(ExpectedConditions.visibilityOfElementLocated(continue_button));
		driver.findElement(continue_button).click();
		myWait.until(ExpectedConditions.visibilityOfElementLocated(creditCard_option));
		driver.findElement(creditCard_option).click();

		//Enter Card Details
		myWait.until(ExpectedConditions.visibilityOfElementLocated(cardnumber));
		driver.findElement(cardnumber).sendKeys(data.get("CardNumber"));//Enter CardNumber
		myWait.until(ExpectedConditions.visibilityOfElementLocated(expiryDate));
		driver.findElement(expiryDate).sendKeys(data.get("ExpiryDate"));//Enter ExpiryDate
		myWait.until(ExpectedConditions.visibilityOfElementLocated(cvv));
		driver.findElement(cvv).sendKeys(data.get("CVV"));//Enter CVV

		//Click on Pay Now Button
		myWait.until(ExpectedConditions.visibilityOfElementLocated(payNow_button));
		driver.findElement(payNow_button).click();
		Thread.sleep(12000);		

		//Copy OTP into clipboard
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		StringSelection otp = new StringSelection(data.get("OTP"));
		clipboard.setContents(otp, null);

		Robot robot = new Robot();
		//Enter OTP
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);

		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_C);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyRelease(KeyEvent.VK_C);

		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyRelease(KeyEvent.VK_V);

		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);

		//Click on ok button
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);

		if (Case == "Success") {
			myWait.until(ExpectedConditions.visibilityOfElementLocated(buynow_button));
			System.out.println("Inside success");
			Assert.assertEquals(driver.findElement(transactionsuccess_1).getText(), "Thank you for your purchase.");
			Assert.assertEquals(driver.findElement(transactionsuccess_2).getText(), "Get a nice sleep.");
		}
		else 
		{
			System.out.println("Inside fail");
			Assert.assertEquals(driver.findElement(transactionfailed).getText(), "Your card got declined by the bank");
			driver.findElement(back_button).click();
		}
	}
	//Validate Invalid CardNumber
	public static void invalidCardNumber(HashMap<String, String> data, WebDriver driver ,WebDriverWait myWait) {
		driver.switchTo().defaultContent();
		myWait.until(ExpectedConditions.visibilityOfElementLocated(buynow_button));
		driver.findElement(buynow_button).click();
		myWait.until(ExpectedConditions.visibilityOfElementLocated(checkout_button));
		driver.findElement(checkout_button).click();

		//Switch to iFrame MindTrans
		driver.switchTo().frame("snap-midtrans");
		myWait.until(ExpectedConditions.visibilityOfElementLocated(continue_button));
		driver.findElement(continue_button).click();
		myWait.until(ExpectedConditions.visibilityOfElementLocated(creditCard_option));
		driver.findElement(creditCard_option).click();

		//Enter Invalid Card Details
		myWait.until(ExpectedConditions.visibilityOfElementLocated(cardnumber));
		driver.findElement(cardnumber).sendKeys(data.get("CardNumber"));
		myWait.until(ExpectedConditions.visibilityOfElementLocated(cardnumberError));
		Assert.assertEquals(driver.findElement(cardnumberError).getText(), "Invalid card number");
	}
}
