package UITestAutomation.GoFin;

import java.awt.AWTException;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

@Listeners(UITestAutomation.GoFin.Listener.class)
public class ExecuteTestCase extends TestBase {
	//Exported Output report path
	public static ExtentReports report = new ExtentReports("ExtentReports\\MediTransExtentReport.html", true);
	public static ExtentTest logger;
	
	@BeforeMethod
	public void startReport() {
		report.addSystemInfo("Host Name", "QA-MediTrans").addSystemInfo("Environment", "Test" + ":\n" + "https://demo.midtrans.com")
				.addSystemInfo("Tester Name", "Hitesh");
	}
	
	@Test(priority = 1)		
	public static void checkout_with_validcard() throws AWTException, InterruptedException {
		logger = report.startTest("checkout_with_validcard", "Check out with valid card details");
		App.Checkout_with(validCardDetails(), driver, myWait, "Success");
		logger.log(LogStatus.PASS, "Checked out with valid credit card successfully");
	}
	@Test(priority = 2)
	public static void checkout_with_invalidcard() throws AWTException, InterruptedException {
		logger = report.startTest("checkout_with_invalidcard", "Validate Check out with Incorrect Card Details");
		App.Checkout_with(invalidCardDetails(), driver, myWait, "Failure");
		logger.log(LogStatus.PASS, "Validated Invalid credit card details");
	}
	@Test(priority = 3)
	public static void checkout_with_invalidcvv() throws AWTException, InterruptedException {
		logger = report.startTest("checkout_with_invalidcvv", "Validate Invalid CVV");
		App.Checkout_with(invalidCvvDetails(), driver, myWait, "Failure");
		logger.log(LogStatus.PASS, "Invalid CVV details validated");
	}
	@Test(priority = 4)
	public static void checkout_with_invalidCardNumber() throws AWTException, InterruptedException {
		logger = report.startTest("checkout_with_invalidCardNumber", "Validate invalid card number");
		App.invalidCardNumber(invalidCardNumber(), driver, myWait);
		logger.log(LogStatus.PASS, "Validated invalid card number successfully");
	}
	
	@AfterMethod
	public void getResult(ITestResult result) {
		if (result.getStatus() == ITestResult.FAILURE) {
			logger.log(LogStatus.FAIL, "Test Case Failed is " + result.getName());
			logger.log(LogStatus.FAIL, "Test Case Failed is " + result.getThrowable());
		} else if (result.getStatus() == ITestResult.SKIP) {
			logger.log(LogStatus.SKIP, "Test Case Skipped is " + result.getName());
		} else if (result.getStatus() == ITestResult.SUCCESS) {
			System.out.println("In Pass");
			logger.log(LogStatus.PASS, "Test Case is pass " + result.getName());
		}
		report.endTest(logger);
		report.flush();
	}// End of function
}
