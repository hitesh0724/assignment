package UITestAutomation.GoFin;

import java.util.ArrayList;
import java.util.List;

import org.testng.ITestListener;
import org.testng.ITestNGMethod;

public class Listener extends TestBase implements ITestListener {

	static List<ITestNGMethod> passedtests = new ArrayList<ITestNGMethod>();
	static List<ITestNGMethod> failedtests = new ArrayList<ITestNGMethod>();
	static List<ITestNGMethod> skippedtests = new ArrayList<ITestNGMethod>();
	static String screenshot_Name;

	public static int[] count_of_test() {
		int[] result = { passedtests.size(), failedtests.size(), skippedtests.size() };
		passedtests = new ArrayList<ITestNGMethod>();
		failedtests = new ArrayList<ITestNGMethod>();
		skippedtests = new ArrayList<ITestNGMethod>();
		return result;
	}
}
