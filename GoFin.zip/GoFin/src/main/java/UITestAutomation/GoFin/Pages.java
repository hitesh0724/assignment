package UITestAutomation.GoFin;

import org.openqa.selenium.By;

public class Pages  {
    public static By buynow_button = By.linkText("BUY NOW");
    public static By checkout_button = By.xpath("//div[@class='cart-checkout'][contains(text(),'CHECKOUT')]");
    public static By continue_button = By.xpath("//a[@href='#/select-payment']");
    public static By frame = By.id("snap-midtrans");
    public static By creditCard_option = By.xpath("//a[@href='#/credit-card']");
    public static By cardnumber = By.name("cardnumber");
    public static By expiryDate = By.xpath("//input[@placeholder='MM / YY']");
    public static By cvv = By.xpath("//input[@placeholder='123']");
    public static By payNow_button = By.xpath("//a[@href='#/']");
    public static By transactionfailed = By.xpath("//div[@class='text-failed']/span");
    public static By transactionsuccess_1 = By.xpath("//div[@class='trans-status trans-success']/span");
    public static By transactionsuccess_2 = By.xpath("//div[@class='trans-status trans-success']/span[2]");
    public static By cardnumberError = By.xpath("//div[@class='notice danger']/div/span");
    public static By back_button = By.xpath("//a[@class='header-back']");
}
