package UITestAutomation.GoFin;

import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeSuite;

public class TestBase extends Pages {
	public static WebDriver driver;
	public static WebDriverWait myWait;
	public static HashMap<String, String> cardData = new HashMap<String, String>();
	
 	public static HashMap<String, String> validCardDetails() {
		cardData.put("CardNumber","4811111111111114");
		cardData.put("ExpiryDate","1224");
		cardData.put("CVV","123");
		cardData.put("OTP","112233");
		return cardData;
 	}
 	public static HashMap<String, String> invalidCardDetails() {
		cardData.put("CardNumber","4911111111111113");
		cardData.put("ExpiryDate","0224");
		cardData.put("CVV","123");
		cardData.put("OTP","112233");
		return cardData;
 	}
 	public static HashMap<String, String> invalidCvvDetails() {
		cardData.put("CardNumber","4811111111111114");
		cardData.put("ExpiryDate","1224");
		cardData.put("CVV","100");
		cardData.put("OTP","112233");
		return cardData;
 	}
 	public static HashMap<String, String> invalidCardNumber() {
		cardData.put("CardNumber","2234876543567765");
		return cardData;
 	}
	@BeforeSuite
	public static void setup() {
        // declaration and instantiation of objects/variables
//    	System.setProperty("webdriver.gecko.driver","resource\\geckodriver.exe");
//		WebDriver driver = new FirefoxDriver();
		//comment the above 2 lines and uncomment below 2 lines to use Chrome
		System.setProperty("webdriver.chrome.driver","resource\\chromedriver.exe");
		ChromeOptions chromeOptions = new ChromeOptions();
		chromeOptions.addArguments("--start-maximized");
		driver = new ChromeDriver(chromeOptions);
        String baseUrl = "https://demo.midtrans.com";
        driver.get(baseUrl);
        myWait  = new WebDriverWait(driver,40);
    }
}
